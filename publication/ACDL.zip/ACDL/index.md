---
title: "ADEL: Autonomous Developmental Evolutionary Learning for Robotic Manipulation"
authors: 
- Yiming Li
- Peng Wang 
- Xiaofei Shen
- Jiayuan Liu
- Haonan Duan
- Chenlin Zhou
date: "2021-06-15T00:00:00Z"
doi: ""

# Schedule page publish date (NOT publication's date).
publishDate: "2017-01-01T00:00:00Z"

# Publication type.
# Legend: 0 = Uncategorized; 1 = Conference paper; 2 = Journal article;
# 3 = Preprint / Working Paper; 4 = Report; 5 = Book; 6 = Book section;
# 7 = Thesis; 8 = Patent
publication_types: ["1"]

# Publication name and optional abbreviated publication name.
publication: In *IEEE International Conference on Development and Learning*
publication_short: In *ICDL 2021*

abstract: Learning approaches have a wide range of applications in the robotic manipulation field. However, traditional supervised or reinforcement learning methods tend to focus on the learning process under specific scenarios, ignoring the possibility of robot autonomous developmental learning driven by changing environment. In this work, we propose a human-like Autonomous Developmental Evolutionary Learning (ADEL) framework combining both genotype (evolution strategies) and phenotype (reinforcement learning), which helps robot learn manipulation tasks from mild environmental change in long time scale (evolution) and interact intensely in short-term range (learning). We introduce the Q-network to interact with the environment for learning manipulation policies and use an evolutionary algorithm to automatically optimize hyper-parameters of the network. Moreover, a composite, variable reward function representation is proposed to improve the performance of our algorithm in different scenarios, which is also optimized by evolution. To demonstrate the performance of the proposed methods, we construct a series of scenarios for robot grasping learning. Experiment results show that by the proposed autonomous developmental evolutionary learning,  robots learn grasping skills with a high success rate and small average steps cost, which suggests that it is possible for robots to learn manipulation skills autonomously, independently and continuously from scratch to adapt to complex environments.

# Summary. An optional shortened abstract.
summary: Learning approaches have a wide range of applications in the robotic manipulation field. However, traditional supervised or reinforcement learning methods

tags:
- Source Themes
featured: true

#links:
#- name: Custom Link
#  url: http://example.org
#url_pdf: http://eprints.soton.ac.uk/352095/1/Cushen-IMV2013.pdf
#url_code: '#'
#url_dataset: '#'
#url_poster: '#'
#url_project: ''
#url_slides: ''
#url_source: '#'
#url_video: '#'

# Featured image
# To use, add an image named `featured.jpg/png` to your page's folder. 
image:
  caption: ''
  focal_point: ""
  preview_only: false

# Associated Projects (optional).
#   Associate this publication with one or more of your projects.
#   Simply enter your project's folder or file name without extension.
#   E.g. `internal-project` references `content/project/internal-project/index.md`.
#   Otherwise, set `projects: []`.
projects:
- internal-project

# Slides (optional).
#   Associate this publication with Markdown slides.
#   Simply enter your slide deck's filename without extension.
#   E.g. `slides: "example"` references `content/slides/example/index.md`.
#   Otherwise, set `slides: ""`.
#slides: example
---


